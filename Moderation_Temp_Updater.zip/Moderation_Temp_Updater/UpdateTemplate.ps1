# 1. Dynamically find the current user's path
$destination = "$env:USERPROFILE\AppData\Local\SybylineNetwork\Scarlet\report_template.txt"

# 2. Get the directory where this script is located
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# 3. Define file paths for external references
$configFile   = Join-Path $scriptDir "config.txt"
$standardFile = Join-Path $scriptDir "template_standard.txt"
$specialFile  = Join-Path $scriptDir "template_special.txt"

# --- START THE LOOP ---
while($true) {
    # 4. Read dates directly from config.txt
    $dates = Get-Content $configFile
    $startDate = [datetime]::Parse($dates[0].Trim())
    $endDate   = [datetime]::Parse($dates[1].Trim())

    # 5. Get current time
    $today = Get-Date

    # 6. Perform the swap
    if ($today -ge $startDate -and $today -le $endDate) {
        if (Test-Path $specialFile) {
            Copy-Item -Path $specialFile -Destination $destination -Force
        }
    } else {
        if (Test-Path $standardFile) {
            Copy-Item -Path $standardFile -Destination $destination -Force
        }
    }

    # 7. Wait for 30 seconds before running again
    Start-Sleep -Seconds 60
}